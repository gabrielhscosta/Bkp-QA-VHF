﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VHF.CommonMethods
{
    public class HospedeFake
    {
        public string CPFFaker { get; set; }
        public string NomeFaker { get; set; }
        public string SobrenomeFaker { get; set; }
        public string EmailFaker { get; set; }
        public string TratamentoHosp { get; set; }
        public string DtNascFaker { get; set; }
        public string CEPFaker { get; set; }
        public string CidadeFaker { get; set; }
    }
}
