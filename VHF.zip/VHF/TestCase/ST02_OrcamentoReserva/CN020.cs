﻿using VHF.Main;
using VHF.CommonMethods;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VHF.TestCase.ST02_OrcamentoReserva
{
    public class CN020 : SessaoMain
    {
        public CN020()
        {

        }

        public void AlterarQuantidadeDiasOrcamento()
        {
            FuncComuns funcComuns = new FuncComuns();
            Validacoes validacoes = new Validacoes();
        }
    }
}
